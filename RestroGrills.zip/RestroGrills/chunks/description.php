<section class="fdes">
		<div class="section white center">
			<h2 class="header" style="padding:20px; padding-bottom: 30px;">Resturant Powered By Grills</h2>
		      <div class="row container center">
		        <div class="col center l8 s12">
		        	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quibusdam ea molestiae, ipsa, tenetur itaque dicta libero delectus incidunt fuga repudiandae est rerum expedita quia debitis quam illo vero laboriosam numquam eius molestias! Quas reprehenderit voluptatem nemo, fugiat modi atque illo earum ea tenetur sed ipsam repellat minus quibusdam doloremque aliquid odio dolorum reiciendis quisquam eum nobis. Laboriosam officia aut, laudantium tempora, voluptates doloremque, quia, reiciendis voluptas voluptatum recusandae ipsam! Illo aliquid possimus porro reiciendis eveniet consectetur eligendi amet. Voluptate officia provident recusandae eum minus aut nam asperiores beatae sit repellat odio maiores quisquam reprehenderit vel sapiente, voluptas facilis harum dolor hic doloribus, dolores. Non quo magni modi consequatur cumque maiores illum veniam quaerat magnam cum nemo harum, veritatis iure possimus, architecto aperiam quas enim reprehenderit voluptates neque corporis perspiciatis. Nihil soluta, sed nisi, et aliquid facere sequi consectetur quaerat quidem voluptatem numquam magnam animi consequatur tempore ipsum iusto veritatis ea!</p>
		        </div>
		       
		        
		      </div>
	</section>